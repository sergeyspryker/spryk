<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @HelloWorld/Index/index.twig */
class __TwigTemplate_0afc1721c52a53df9c36df38e9cb75a240d0936965f826c57b30a4c3db65d27a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'widget_content' => [$this, 'block_widget_content'],
            'footer_js' => [$this, 'block_footer_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@HelloWorld/Layout/layout.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@HelloWorld/Layout/layout.twig", "@HelloWorld/Index/index.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        $this->displayBlock('widget_content', $context, $blocks);
    }

    public function block_widget_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <p>";
        // line 8
        echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
        echo "</p>
                </div>
            </div>
        </div>
    ";
    }

    // line 15
    public function block_footer_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 16
        echo "    ";
        $this->displayParentBlock("footer_js", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "@HelloWorld/Index/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 16,  74 => 15,  65 => 8,  60 => 5,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '@HelloWorld/Layout/layout.twig' %}

{% block content %}
    {% block widget_content %}
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <p>{{ message }}</p>
                </div>
            </div>
        </div>
    {% endblock %}
{% endblock %}

{% block footer_js %}
    {{ parent() }}
{% endblock %}
", "@HelloWorld/Index/index.twig", "/data/src/App/Zed/HelloWorld/Presentation//Index/index.twig");
    }
}
