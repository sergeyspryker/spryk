<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication;

use Spryker\Zed\Kernel\Communication\AbstractCommunicationFactory;

/**
 * @method \App\Zed\HelloWorld\HelloWorldConfig getConfig()
 * @method \App\Zed\HelloWorld\Business\HelloWorldFacadeInterface getFacade()
 */
class HelloWorldCommunicationFactory extends AbstractCommunicationFactory
{
}
