<?php

return 'DEFAULT';
