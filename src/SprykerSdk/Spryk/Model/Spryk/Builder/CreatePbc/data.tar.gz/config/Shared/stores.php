<?php

$stores = [];

$stores['DEFAULT'] = [
    'locales' => [
        'en' => 'en_US',
        'de' => 'de_DE',
    ],
    // first entry is default
    'countries' => ['DE', 'AT', 'NO', 'CH', 'ES', 'GB'],
    // internal and shop
    'currencyIsoCode' => 'EUR',
    'currencyIsoCodes' => ['EUR', 'CHF'],
];
$stores['DE'] = [
    'locales' => [
        'en' => 'en_US',
        'de' => 'de_DE',
    ],
    // first entry is default
    'countries' => ['DE', 'AT', 'NO', 'CH', 'ES', 'GB'],
    // internal and shop
    'currencyIsoCode' => 'EUR',
    'currencyIsoCodes' => ['EUR', 'CHF'],
];

return $stores;
