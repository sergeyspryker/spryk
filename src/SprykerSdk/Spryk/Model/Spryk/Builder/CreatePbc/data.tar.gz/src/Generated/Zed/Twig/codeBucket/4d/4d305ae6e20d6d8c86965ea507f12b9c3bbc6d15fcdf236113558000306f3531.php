<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @Gui/Layout/layout.twig */
class __TwigTemplate_4186771db9e460a7a4b1f1eaf26fa4ec0d9bc768ee28c0fa506183b984cc406d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head_title' => [$this, 'block_head_title'],
            'head_css' => [$this, 'block_head_css'],
            'content' => [$this, 'block_content'],
            'footer_js' => [$this, 'block_footer_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html data-application-locale=\"";
        // line 2
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 2), "html", null, true);
        echo "\">
<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    <title>";
        // line 8
        $this->displayBlock('head_title', $context, $blocks);
        echo "</title>

    ";
        // line 10
        $this->displayBlock('head_css', $context, $blocks);
        // line 14
        echo "
</head>
<body>

<div id=\"wrapper\">
    <div class=\"gray-bg\">
        <div class=\"wrapper wrapper-content\">

            ";
        // line 22
        $this->displayBlock('content', $context, $blocks);
        // line 23
        echo "
        </div>
    </div>
</div>


";
        // line 29
        $this->displayBlock('footer_js', $context, $blocks);
        // line 31
        echo "
</body>
</html>
";
    }

    // line 8
    public function block_head_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        if ((isset($context["title"]) || array_key_exists("title", $context))) {
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "html", null, true);
        }
    }

    // line 10
    public function block_head_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 11
        echo "        <link rel=\"stylesheet\" href=\"";
        echo call_user_func_array($this->env->getFunction('assetsPath')->getCallable(), ["css/spryker-zed-gui-commons.css"]);
        echo "\">
        <link href=\"https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&family=Montserrat:wght@400;500;600;700&display=swap\" rel=\"stylesheet\">
    ";
    }

    // line 22
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 29
    public function block_footer_js($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "@Gui/Layout/layout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 29,  110 => 22,  102 => 11,  98 => 10,  89 => 8,  82 => 31,  80 => 29,  72 => 23,  70 => 22,  60 => 14,  58 => 10,  53 => 8,  44 => 2,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html data-application-locale=\"{{ app.locale }}\">
<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    <title>{% block head_title %}{% if title is defined %}{{ title | trans }}{% endif %}{% endblock %}</title>

    {% block head_css %}
        <link rel=\"stylesheet\" href=\"{{ assetsPath('css/spryker-zed-gui-commons.css') }}\">
        <link href=\"https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&family=Montserrat:wght@400;500;600;700&display=swap\" rel=\"stylesheet\">
    {% endblock %}

</head>
<body>

<div id=\"wrapper\">
    <div class=\"gray-bg\">
        <div class=\"wrapper wrapper-content\">

            {% block content -%}{%- endblock %}

        </div>
    </div>
</div>


{% block footer_js %}
{% endblock %}

</body>
</html>
", "@Gui/Layout/layout.twig", "/data/src/App/Zed/Gui/Presentation//Layout/layout.twig");
    }
}
