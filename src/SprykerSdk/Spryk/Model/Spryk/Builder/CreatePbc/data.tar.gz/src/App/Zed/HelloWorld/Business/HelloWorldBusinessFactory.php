<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Business;

use Spryker\Zed\Kernel\Business\AbstractBusinessFactory;

/**
 * @method \App\Zed\HelloWorld\HelloWorldConfig getConfig()
 * @method \App\Zed\HelloWorld\Persistence\HelloWorldEntityManagerInterface getEntityManager()
 * @method \App\Zed\HelloWorld\Persistence\HelloWorldRepositoryInterface getRepository()
 */
class HelloWorldBusinessFactory extends AbstractBusinessFactory
{

}
