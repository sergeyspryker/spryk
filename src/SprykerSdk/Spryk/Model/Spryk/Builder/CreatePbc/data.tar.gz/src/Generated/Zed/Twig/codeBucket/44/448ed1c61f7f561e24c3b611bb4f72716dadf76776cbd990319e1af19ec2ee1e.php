<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @HelloWorld/Index/confirmation.twig */
class __TwigTemplate_65ecae99351ac2e4d4ff154c880475df9838d9457afce322486d821df29e453b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'widget_content' => [$this, 'block_widget_content'],
            'footer_js' => [$this, 'block_footer_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@Gui/Layout/layout.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@Gui/Layout/layout.twig", "@HelloWorld/Index/confirmation.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        $this->displayBlock('widget_content', $context, $blocks);
    }

    public function block_widget_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-6\">
                    <div style=\"margin: 0 auto;\">
                    <form action=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["url"] ?? null), "html", null, true);
        echo "\">
                        <div style=\"padding-bottom: 40px;\"><img src=\"https://www.wikicorporates.org/mediawiki/images/thumb/3/31/Lehman-Brothers-stacked.svg/500px-Lehman-Brothers-stacked.svg.png\"></div>


                        <label for=\"confirm\"><input type=\"checkbox\" required id=\"confirm\">&nbsp;I accept terms and conditions.</label>
                        <div class=\"row\" style=\"width: 100%;\">
                            <div class=\"col-lg-12\" style=\"padding-top: 30px;\">
                                <div style=\"float: left;\"><a class=\"btn btn-remove\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, ($context["cancel"] ?? null), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Cancel"), "html", null, true);
        echo "</a></div>
                                <div style=\"float: right;\"><button class=\"btn\" type=\"submit\">";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Confirm payment"), "html", null, true);
        echo "</button></div>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    ";
    }

    // line 28
    public function block_footer_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 29
        echo "    ";
        $this->displayParentBlock("footer_js", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "@HelloWorld/Index/confirmation.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 29,  95 => 28,  82 => 17,  76 => 16,  66 => 9,  60 => 5,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends '@Gui/Layout/layout.twig' %}

{% block content %}
    {% block widget_content %}
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-6\">
                    <div style=\"margin: 0 auto;\">
                    <form action=\"{{ url }}\">
                        <div style=\"padding-bottom: 40px;\"><img src=\"https://www.wikicorporates.org/mediawiki/images/thumb/3/31/Lehman-Brothers-stacked.svg/500px-Lehman-Brothers-stacked.svg.png\"></div>


                        <label for=\"confirm\"><input type=\"checkbox\" required id=\"confirm\">&nbsp;I accept terms and conditions.</label>
                        <div class=\"row\" style=\"width: 100%;\">
                            <div class=\"col-lg-12\" style=\"padding-top: 30px;\">
                                <div style=\"float: left;\"><a class=\"btn btn-remove\" href=\"{{ cancel }}\">{{ 'Cancel' | trans }}</a></div>
                                <div style=\"float: right;\"><button class=\"btn\" type=\"submit\">{{ 'Confirm payment' | trans }}</button></div>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    {% endblock %}
{% endblock %}

{% block footer_js %}
    {{ parent() }}
{% endblock %}
", "@HelloWorld/Index/confirmation.twig", "/data/src/App/Zed/HelloWorld/Presentation//Index/confirmation.twig");
    }
}
