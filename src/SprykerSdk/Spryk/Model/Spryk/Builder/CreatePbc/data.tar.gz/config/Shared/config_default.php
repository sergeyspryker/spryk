<?php

use App\Shared\Event\EventConfig;
use App\Shared\Scheduler\SchedulerConfig;
use Spryker\Shared\Application\ApplicationConstants;
use Spryker\Shared\ErrorHandler\ErrorHandlerConstants;
use Spryker\Shared\EventAwsSnsBroker\EventAwsSnsBrokerConstants;
use Spryker\Shared\Kernel\KernelConstants;
use Spryker\Shared\Router\RouterConstants;
use Spryker\Shared\Scheduler\SchedulerConstants;
use Spryker\Shared\SchedulerJenkins\SchedulerJenkinsConfig;
use Spryker\Shared\SchedulerJenkins\SchedulerJenkinsConstants;

// >>> LOGGING

// Due to some deprecation notices we silence all deprecations for the time being
$config[ErrorHandlerConstants::ERROR_LEVEL] = E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED;
$config[ErrorHandlerConstants::ERROR_LEVEL_LOG_ONLY] = E_DEPRECATED | E_USER_DEPRECATED;

$config[KernelConstants::PROJECT_NAMESPACE] = 'App';
$config[KernelConstants::PROJECT_NAMESPACES] = [
    'App',
];
$config[KernelConstants::CORE_NAMESPACES] = [
    'Spryker',
];

// >>> AWS SNS Event Broker

$config[EventAwsSnsBrokerConstants::EVENT_AWS_SNS_BROKER_CONFIG] = [
    EventAwsSnsBrokerConstants::AWS_SNS_ACCESS_KEY => getenv('AWS_ACCESS_KEY_ID'),
    EventAwsSnsBrokerConstants::AWS_SNS_ACCESS_SECRET => getenv('AWS_SECRET_ACCESS_KEY'),
    EventAwsSnsBrokerConstants::AWS_SNS_REGION => getenv('AWS_DEFAULT_REGION'),
    EventAwsSnsBrokerConstants::AWS_SNS_ENDPOINT => getenv('AWS_ENDPOINT'),
    EventAwsSnsBrokerConstants::AWS_SNS_VERSION => getenv('AWS_SNS_VERSION'),
];
$config[EventAwsSnsBrokerConstants::AWS_SNS_BUS_NAMES_TOPIC_ARN] = [];

$awsSnsTopicNames = json_decode(html_entity_decode(getenv('AWS_SNS_TOPICS') ?: '[]', ENT_QUOTES), true) ?: [
    EventConfig::EVENT_BUS_APPS,
];
$awsRegion = getenv('AWS_DEFAULT_REGION') ?: '';
$awsAccountId = getenv('AWS_ACCOUNT_ID') ?: '';

foreach ($awsSnsTopicNames as $awsSnsTopicName) {
    $config[EventAwsSnsBrokerConstants::AWS_SNS_BUS_NAMES_TOPIC_ARN][$awsSnsTopicName] = sprintf(
        'arn:aws:sns:%s:%s:%s',
        $awsRegion,
        $awsAccountId,
        $awsSnsTopicName
    );
}

$config[ApplicationConstants::BASE_URL_ZED] = sprintf(
    '%s://%s',
    getenv('SPRYKER_BE_PROTOCOL') ?: 'http',
    getenv('SPRYKER_BE_HOST')
);
$config[RouterConstants::ZED_IS_SSL_ENABLED] = false;

// >>> SCHEDULER
$config[SchedulerConstants::ENABLED_SCHEDULERS] = [
    SchedulerConfig::SCHEDULER_JENKINS,
];
$config[SchedulerJenkinsConstants::JENKINS_CONFIGURATION] = [
    SchedulerConfig::SCHEDULER_JENKINS => [
        SchedulerJenkinsConfig::SCHEDULER_JENKINS_BASE_URL => sprintf(
            '%s://%s:%s/',
            getenv('SPRYKER_SCHEDULER_PROTOCOL') ?: 'http',
            getenv('SPRYKER_SCHEDULER_HOST'),
            getenv('SPRYKER_SCHEDULER_PORT')
        ),
    ],
];

$config[SchedulerJenkinsConstants::JENKINS_TEMPLATE_PATH] = getenv('SPRYKER_JENKINS_TEMPLATE_PATH') ?: null;
