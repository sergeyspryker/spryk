<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\Application\Communication\Plugin\EventDispatcher;

use Spryker\Service\Container\ContainerInterface;
use Spryker\Shared\EventDispatcher\EventDispatcherInterface;
use Spryker\Shared\EventDispatcherExtension\Dependency\Plugin\EventDispatcherPluginInterface;
use Spryker\Zed\Kernel\Communication\AbstractPlugin;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * @method \Spryker\Zed\Application\ApplicationConfig getConfig()
 */
class DisableSecurityHeadersEventDispatcherPlugin extends AbstractPlugin implements EventDispatcherPluginInterface
{
    /**
     * For this routes security headers will be removed
     */
    protected const LIST_OF_ROUTES_WITHOUT_SECURITY_HEADERS = [];

    /**
     * Next headers will be removed for specific routes
     */
    protected const HEADERS_TO_BE_REMOVED = [
        'X-Frame-Options',
        'Content-Security-Policy',
    ];

    /**
     * {@inheritDoc}
     * - Extends EventDispatch with a KernelEvents::RESPONSE event to remove security headers from config for concrete routes.
     *
     * @api
     *
     * @param \Spryker\Shared\EventDispatcher\EventDispatcherInterface $eventDispatcher
     * @param \Spryker\Service\Container\ContainerInterface $container
     *
     * @return \Spryker\Shared\EventDispatcher\EventDispatcherInterface
     */
    public function extend(EventDispatcherInterface $eventDispatcher, ContainerInterface $container): EventDispatcherInterface
    {
        $eventDispatcher->addListener(
            KernelEvents::RESPONSE,
            function (ResponseEvent $event) {
                $securityHeaders = $this->getConfig()->getSecurityHeaders();

                $route = $event->getRequest()->attributes->get('_route');

                if (!in_array($route, static::LIST_OF_ROUTES_WITHOUT_SECURITY_HEADERS)) {
                    return;
                }

                foreach ($securityHeaders as $securityHeaderName => $securityHeaderValue) {
                    if ($securityHeaderValue && in_array($securityHeaderName, static::HEADERS_TO_BE_REMOVED)) {
                        $event->getResponse()->headers->remove($securityHeaderName);
                    }
                }
            }
        );

        return $eventDispatcher;
    }
}
