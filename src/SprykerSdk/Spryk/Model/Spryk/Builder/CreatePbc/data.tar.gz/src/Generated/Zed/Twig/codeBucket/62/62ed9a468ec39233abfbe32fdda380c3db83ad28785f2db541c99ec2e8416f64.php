<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @HelloWorld/Layout/layout.twig */
class __TwigTemplate_bc0920f3435e0cd993e396fcff65c4a9e91c87d9f1a78cfd4abb28b6ac0dd246 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>PBC Success</title>
</head>
<body>
<table width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">
    <tbody>
    <tr>
        <td align=\"center\">
            <table class=\"col-600\" width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">
                <tbody>
                <tr>
                    <td align=\"center\" valign=\"top\"
                        background=\"https://spryker.com/app/uploads/dynamic/2020/09/1920x800px_HeroHeaderImage_Desktop_EXCITE_Main-Stage-1-700x0-c-default.jpg\"
                        bgcolor=\"#66809b\" style=\"background-size:cover; background-position:top;height:400;\">
                    <table class=\"col-600\" width=\"600\" height=\"400\" border=\"0\" align=\"center\" cellpadding=\"0\"
                           cellspacing=\"0\">

                        <tbody>
                        <tr>
                            <td height=\"40\"></td>
                        </tr>


                        <tr>
                            <td align=\"center\" style=\"line-height: 0px;\">
                                <img
                                    style=\"display:block; background-color:white  ; line-height:0px; font-size:0px; border:0px;\"
                                    src=\"https://spryker.com/app/uploads/2020/04/Logo_Spryker_horizontal_black_RGB.svg \"
                                    width=\"109\" height=\"115\" alt=\"logo\">
                            </td>
                        </tr>


                        <tr>
                            <td align=\"center\"
                                style=\"font-family: 'Raleway', sans-serif; font-size:37px; color:#ffffff; line-height:24px; font-weight: bold; letter-spacing: 5px;\">
                                <span style=\"font-family: 'Raleway', sans-serif; font-size:37px; color:#ffffff; line-height:39px; font-weight: 300; letter-spacing: 5px;\">
                                    ";
        // line 41
        $this->displayBlock('content', $context, $blocks);
        // line 42
        echo "                                </span>
                            </td>
                        </tr>


                        <tr>
                            <td align=\"center\"
                                style=\"font-family: 'Lato', sans-serif; font-size:15px; color:#ffffff; line-height:24px; font-weight: 300;\">
                                PBC status <br>Correct.
                            </td>
                        </tr>


                        <tr>
                            <td height=\"50\"></td>
                        </tr>
                        </tbody>
                    </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>


    <!-- END HEADERR -->


    <!-- START SHOWCASE -->

    <tr>
        <td align=\"center\">
            <table class=\"col-600\" width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"
                   style=\"margin-left:20px; margin-right:20px; border-left: 1px solid #dbd9d9; border-right: 1px solid #dbd9d9;\">
                <tbody>
                <tr>
                    <td height=\"35\"></td>
                </tr>

                <tr>
                    <td align=\"center\"
                        style=\"font-family: 'Raleway', sans-serif; font-size:22px; font-weight: bold; color:#333;\">
                        LehmanBrothersPSP
                    </td>
                </tr>

                <tr>
                    <td height=\"10\"></td>
                </tr>


                <tr>
                    <td align=\"center\"
                        style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                        <br> This PSP will automatically connect to our Payment API and manage Payments, Notifications,
                        Credit Memos and Refunds automatically based on the common hooks in Order Management PBC, for
                        more info please check our documentation.
                    </td>
                </tr>

                </tbody>
            </table>
        </td>
    </tr>

    <tr>
        <td align=\"center\">
            <table class=\"col-600\" width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"
                   style=\"border-left: 1px solid #dbd9d9; border-right: 1px solid #dbd9d9; \">
                <tbody>
                <tr>
                    <td height=\"10\"></td>
                </tr>
                <tr>
                    <td>

                        <table class=\"col3\" width=\"183\" border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            <tr>
                                <td align=\"center\">
                                    <table class=\"insider\" width=\"133\" border=\"0\" align=\"center\" cellpadding=\"0\"
                                           cellspacing=\"0\">

                                        <tbody>
                                        <tr align=\"center\" style=\"line-height:0px;\">
                                            <td>
                                                <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\"
                                                     src=\"https://spryker.com/app/uploads/dynamic/2021/08/Easy-Integration-660x580-c-default.png\"
                                                     width=\"78\" height=\"78\" alt=\"icon\">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"15\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Raleway', Arial, sans-serif; font-size:20px; color:#333; line-height:24px; font-weight: bold;\">
                                                Contact PBC Developer
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"10\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                                                Lehman Brothers IT division Sec 2
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            </tbody>
                        </table>


                        <table width=\"1\" height=\"20\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"left\">
                            <tbody>
                            <tr>
                                <td height=\"20\" style=\"font-size: 0;line-height: 0;border-collapse: collapse;\">
                                    <p style=\"padding-left: 24px;\">&nbsp;</p>
                                </td>
                            </tr>
                            </tbody>
                        </table>


                        <table class=\"col3\" width=\"183\" border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            <tr>
                                <td align=\"center\">
                                    <table class=\"insider\" width=\"133\" border=\"0\" align=\"center\" cellpadding=\"0\"
                                           cellspacing=\"0\">

                                        <tbody>
                                        <tr align=\"center\" style=\"line-height:0px;\">
                                            <td>
                                                <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\"
                                                     src=\"https://spryker.com/app/uploads/dynamic/2021/08/Better-Customer-Engagement-660x580-c-default.png\"
                                                     width=\"78\" height=\"78\" alt=\"icon\">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"15\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Raleway', sans-serif; font-size:20px; color:#333; line-height:24px; font-weight: bold;\">
                                                Release Notes
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"10\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                                                Check latest release notes
                                            </td>
                                        </tr>


                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            </tbody>
                        </table>


                        <table width=\"1\" height=\"20\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"left\">
                            <tbody>
                            <tr>
                                <td height=\"20\" style=\"font-size: 0;line-height: 0;border-collapse: collapse;\">
                                    <p style=\"padding-left: 24px;\">&nbsp;</p>
                                </td>
                            </tr>
                            </tbody>
                        </table>


                        <table class=\"col3\" width=\"183\" border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            <tr>
                                <td align=\"center\">
                                    <table class=\"insider\" width=\"133\" border=\"0\" align=\"center\" cellpadding=\"0\"
                                           cellspacing=\"0\">

                                        <tbody>
                                        <tr align=\"center\" style=\"line-height:0px;\">
                                            <td>
                                                <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\"
                                                     src=\"https://spryker.com/app/uploads/dynamic/2021/08/Better-Online-Revenue-660x580-c-default.png\"
                                                     width=\"78\" height=\"78\" alt=\"icon\">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"15\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Raleway',  sans-serif; font-size:20px; color:#333; line-height:24px; font-weight: bold;\">
                                                Capabilities
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"10\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                                                Complete list of PBC capabilities
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            </tbody>
                        </table>


                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>

    <tr>
        <td height=\"5\"></td>
    </tr>
    <!-- END SHOWCASE -->

    </tbody>
</table>

</body>
</html>
";
    }

    // line 41
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "@HelloWorld/Layout/layout.twig";
    }

    public function getDebugInfo()
    {
        return array (  365 => 41,  82 => 42,  80 => 41,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>PBC Success</title>
</head>
<body>
<table width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">
    <tbody>
    <tr>
        <td align=\"center\">
            <table class=\"col-600\" width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">
                <tbody>
                <tr>
                    <td align=\"center\" valign=\"top\"
                        background=\"https://spryker.com/app/uploads/dynamic/2020/09/1920x800px_HeroHeaderImage_Desktop_EXCITE_Main-Stage-1-700x0-c-default.jpg\"
                        bgcolor=\"#66809b\" style=\"background-size:cover; background-position:top;height:400;\">
                    <table class=\"col-600\" width=\"600\" height=\"400\" border=\"0\" align=\"center\" cellpadding=\"0\"
                           cellspacing=\"0\">

                        <tbody>
                        <tr>
                            <td height=\"40\"></td>
                        </tr>


                        <tr>
                            <td align=\"center\" style=\"line-height: 0px;\">
                                <img
                                    style=\"display:block; background-color:white  ; line-height:0px; font-size:0px; border:0px;\"
                                    src=\"https://spryker.com/app/uploads/2020/04/Logo_Spryker_horizontal_black_RGB.svg \"
                                    width=\"109\" height=\"115\" alt=\"logo\">
                            </td>
                        </tr>


                        <tr>
                            <td align=\"center\"
                                style=\"font-family: 'Raleway', sans-serif; font-size:37px; color:#ffffff; line-height:24px; font-weight: bold; letter-spacing: 5px;\">
                                <span style=\"font-family: 'Raleway', sans-serif; font-size:37px; color:#ffffff; line-height:39px; font-weight: 300; letter-spacing: 5px;\">
                                    {% block content -%}{%- endblock %}
                                </span>
                            </td>
                        </tr>


                        <tr>
                            <td align=\"center\"
                                style=\"font-family: 'Lato', sans-serif; font-size:15px; color:#ffffff; line-height:24px; font-weight: 300;\">
                                PBC status <br>Correct.
                            </td>
                        </tr>


                        <tr>
                            <td height=\"50\"></td>
                        </tr>
                        </tbody>
                    </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>


    <!-- END HEADERR -->


    <!-- START SHOWCASE -->

    <tr>
        <td align=\"center\">
            <table class=\"col-600\" width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"
                   style=\"margin-left:20px; margin-right:20px; border-left: 1px solid #dbd9d9; border-right: 1px solid #dbd9d9;\">
                <tbody>
                <tr>
                    <td height=\"35\"></td>
                </tr>

                <tr>
                    <td align=\"center\"
                        style=\"font-family: 'Raleway', sans-serif; font-size:22px; font-weight: bold; color:#333;\">
                        LehmanBrothersPSP
                    </td>
                </tr>

                <tr>
                    <td height=\"10\"></td>
                </tr>


                <tr>
                    <td align=\"center\"
                        style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                        <br> This PSP will automatically connect to our Payment API and manage Payments, Notifications,
                        Credit Memos and Refunds automatically based on the common hooks in Order Management PBC, for
                        more info please check our documentation.
                    </td>
                </tr>

                </tbody>
            </table>
        </td>
    </tr>

    <tr>
        <td align=\"center\">
            <table class=\"col-600\" width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"
                   style=\"border-left: 1px solid #dbd9d9; border-right: 1px solid #dbd9d9; \">
                <tbody>
                <tr>
                    <td height=\"10\"></td>
                </tr>
                <tr>
                    <td>

                        <table class=\"col3\" width=\"183\" border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            <tr>
                                <td align=\"center\">
                                    <table class=\"insider\" width=\"133\" border=\"0\" align=\"center\" cellpadding=\"0\"
                                           cellspacing=\"0\">

                                        <tbody>
                                        <tr align=\"center\" style=\"line-height:0px;\">
                                            <td>
                                                <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\"
                                                     src=\"https://spryker.com/app/uploads/dynamic/2021/08/Easy-Integration-660x580-c-default.png\"
                                                     width=\"78\" height=\"78\" alt=\"icon\">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"15\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Raleway', Arial, sans-serif; font-size:20px; color:#333; line-height:24px; font-weight: bold;\">
                                                Contact PBC Developer
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"10\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                                                Lehman Brothers IT division Sec 2
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            </tbody>
                        </table>


                        <table width=\"1\" height=\"20\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"left\">
                            <tbody>
                            <tr>
                                <td height=\"20\" style=\"font-size: 0;line-height: 0;border-collapse: collapse;\">
                                    <p style=\"padding-left: 24px;\">&nbsp;</p>
                                </td>
                            </tr>
                            </tbody>
                        </table>


                        <table class=\"col3\" width=\"183\" border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            <tr>
                                <td align=\"center\">
                                    <table class=\"insider\" width=\"133\" border=\"0\" align=\"center\" cellpadding=\"0\"
                                           cellspacing=\"0\">

                                        <tbody>
                                        <tr align=\"center\" style=\"line-height:0px;\">
                                            <td>
                                                <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\"
                                                     src=\"https://spryker.com/app/uploads/dynamic/2021/08/Better-Customer-Engagement-660x580-c-default.png\"
                                                     width=\"78\" height=\"78\" alt=\"icon\">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"15\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Raleway', sans-serif; font-size:20px; color:#333; line-height:24px; font-weight: bold;\">
                                                Release Notes
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"10\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                                                Check latest release notes
                                            </td>
                                        </tr>


                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            </tbody>
                        </table>


                        <table width=\"1\" height=\"20\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"left\">
                            <tbody>
                            <tr>
                                <td height=\"20\" style=\"font-size: 0;line-height: 0;border-collapse: collapse;\">
                                    <p style=\"padding-left: 24px;\">&nbsp;</p>
                                </td>
                            </tr>
                            </tbody>
                        </table>


                        <table class=\"col3\" width=\"183\" border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\">
                            <tbody>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            <tr>
                                <td align=\"center\">
                                    <table class=\"insider\" width=\"133\" border=\"0\" align=\"center\" cellpadding=\"0\"
                                           cellspacing=\"0\">

                                        <tbody>
                                        <tr align=\"center\" style=\"line-height:0px;\">
                                            <td>
                                                <img style=\"display:block; line-height:0px; font-size:0px; border:0px;\"
                                                     src=\"https://spryker.com/app/uploads/dynamic/2021/08/Better-Online-Revenue-660x580-c-default.png\"
                                                     width=\"78\" height=\"78\" alt=\"icon\">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"15\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Raleway',  sans-serif; font-size:20px; color:#333; line-height:24px; font-weight: bold;\">
                                                Capabilities
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height=\"10\"></td>
                                        </tr>


                                        <tr align=\"center\">
                                            <td style=\"font-family: 'Lato', sans-serif; font-size:14px; color:#757575; line-height:24px; font-weight: 300;\">
                                                Complete list of PBC capabilities
                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height=\"30\"></td>
                            </tr>
                            </tbody>
                        </table>


                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>

    <tr>
        <td height=\"5\"></td>
    </tr>
    <!-- END SHOWCASE -->

    </tbody>
</table>

</body>
</html>
", "@HelloWorld/Layout/layout.twig", "/data/src/App/Zed/HelloWorld/Presentation//Layout/layout.twig");
    }
}
