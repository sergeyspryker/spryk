<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Shared\Event;

use Spryker\Shared\Event\EventConfig as SprykerEventConfig;

class EventConfig extends SprykerEventConfig
{
    /**
     * Specification:
     * - Name of the event bus for the apps from AppStore.
     *
     * @api
     */
    public const EVENT_BUS_APPS = 'apps';
}
