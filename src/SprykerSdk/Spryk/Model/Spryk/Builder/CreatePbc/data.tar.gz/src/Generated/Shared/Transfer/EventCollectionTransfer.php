<?php

/**
 * (c) Spryker Systems GmbH copyright protected
 */

namespace Generated\Shared\Transfer;

use ArrayObject;
use Spryker\Shared\Kernel\Transfer\AbstractTransfer;

/**
 * !!! THIS FILE IS AUTO-GENERATED, EVERY CHANGE WILL BE LOST WITH THE NEXT RUN OF TRANSFER GENERATOR
 * !!! DO NOT CHANGE ANYTHING IN THIS FILE
 */
class EventCollectionTransfer extends AbstractTransfer
{
    /**
     * @var string
     */
    public const EVENTS = 'events';

    /**
     * @var string
     */
    public const EVENT_BUS_NAME = 'eventBusName';

    /**
     * @var \ArrayObject|\Generated\Shared\Transfer\EventTransfer[]
     */
    protected $events;

    /**
     * @var string|null
     */
    protected $eventBusName;

    /**
     * @var array
     */
    protected $transferPropertyNameMap = [
        'events' => 'events',
        'Events' => 'events',
        'event_bus_name' => 'eventBusName',
        'eventBusName' => 'eventBusName',
        'EventBusName' => 'eventBusName',
    ];

    /**
     * @var array
     */
    protected $transferMetadata = [
        self::EVENTS => [
            'type' => 'Generated\Shared\Transfer\EventTransfer',
            'type_shim' => null,
            'name_underscore' => 'events',
            'is_collection' => true,
            'is_transfer' => true,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::EVENT_BUS_NAME => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'event_bus_name',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
    ];

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @param \ArrayObject|\Generated\Shared\Transfer\EventTransfer[] $events
     *
     * @return $this
     */
    public function setEvents(ArrayObject $events)
    {
        $this->events = $events;
        $this->modifiedProperties[self::EVENTS] = true;

        return $this;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @return \ArrayObject|\Generated\Shared\Transfer\EventTransfer[]
     */
    public function getEvents()
    {
        return $this->events;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @param \Generated\Shared\Transfer\EventTransfer $event
     *
     * @return $this
     */
    public function addEvent(EventTransfer $event)
    {
        $this->events[] = $event;
        $this->modifiedProperties[self::EVENTS] = true;

        return $this;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireEvents()
    {
        $this->assertCollectionPropertyIsSet(self::EVENTS);

        return $this;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @param string|null $eventBusName
     *
     * @return $this
     */
    public function setEventBusName($eventBusName)
    {
        $this->eventBusName = $eventBusName;
        $this->modifiedProperties[self::EVENT_BUS_NAME] = true;

        return $this;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @return string|null
     */
    public function getEventBusName()
    {
        return $this->eventBusName;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getEventBusNameOrFail()
    {
        if ($this->eventBusName === null) {
            $this->throwNullValueException(static::EVENT_BUS_NAME);
        }

        return $this->eventBusName;
    }

    /**
     * @module EventAwsSnsBroker|Event
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireEventBusName()
    {
        $this->assertPropertyIsSet(self::EVENT_BUS_NAME);

        return $this;
    }

    /**
     * @param array $data
     * @param bool $ignoreMissingProperty
     *
     * @throws \InvalidArgumentException
     *
     * @return $this
     */
    public function fromArray(array $data, $ignoreMissingProperty = false)
    {
        foreach ($data as $property => $value) {
            $normalizedPropertyName = $this->transferPropertyNameMap[$property] ?? null;

            switch ($normalizedPropertyName) {
                case 'eventBusName':
                    $this->$normalizedPropertyName = $value;
                    $this->modifiedProperties[$normalizedPropertyName] = true;

                    break;
                case 'events':
                    $elementType = $this->transferMetadata[$normalizedPropertyName]['type'];
                    $this->$normalizedPropertyName = $this->processArrayObject($elementType, $value, $ignoreMissingProperty);
                    $this->modifiedProperties[$normalizedPropertyName] = true;

                    break;
                default:
                    if (!$ignoreMissingProperty) {
                        throw new \InvalidArgumentException(sprintf('Missing property `%s` in `%s`', $property, static::class));
                    }
            }
        }

        return $this;
    }

    /**
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    public function modifiedToArray($isRecursive = true, $camelCasedKeys = false)
    {
        if ($isRecursive && !$camelCasedKeys) {
            return $this->modifiedToArrayRecursiveNotCamelCased();
        }
        if ($isRecursive && $camelCasedKeys) {
            return $this->modifiedToArrayRecursiveCamelCased();
        }
        if (!$isRecursive && $camelCasedKeys) {
            return $this->modifiedToArrayNotRecursiveCamelCased();
        }
        if (!$isRecursive && !$camelCasedKeys) {
            return $this->modifiedToArrayNotRecursiveNotCamelCased();
        }
    }

    /**
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    public function toArray($isRecursive = true, $camelCasedKeys = false)
    {
        if ($isRecursive && !$camelCasedKeys) {
            return $this->toArrayRecursiveNotCamelCased();
        }
        if ($isRecursive && $camelCasedKeys) {
            return $this->toArrayRecursiveCamelCased();
        }
        if (!$isRecursive && !$camelCasedKeys) {
            return $this->toArrayNotRecursiveNotCamelCased();
        }
        if (!$isRecursive && $camelCasedKeys) {
            return $this->toArrayNotRecursiveCamelCased();
        }
    }

    /**
     * @param mixed $value
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    protected function addValuesToCollectionModified($value, $isRecursive, $camelCasedKeys)
    {
        $result = [];
        foreach ($value as $elementKey => $arrayElement) {
            if ($arrayElement instanceof AbstractTransfer) {
                $result[$elementKey] = $arrayElement->modifiedToArray($isRecursive, $camelCasedKeys);

                continue;
            }
            $result[$elementKey] = $arrayElement;
        }

        return $result;
    }

    /**
     * @param mixed $value
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    protected function addValuesToCollection($value, $isRecursive, $camelCasedKeys)
    {
        $result = [];
        foreach ($value as $elementKey => $arrayElement) {
            if ($arrayElement instanceof AbstractTransfer) {
                $result[$elementKey] = $arrayElement->toArray($isRecursive, $camelCasedKeys);

                continue;
            }
            $result[$elementKey] = $arrayElement;
        }

        return $result;
    }

    /**
     * @return array
     */
    public function modifiedToArrayRecursiveCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $property;

            if ($value instanceof AbstractTransfer) {
                $values[$arrayKey] = $value->modifiedToArray(true, true);

                continue;
            }
            switch ($property) {
                case 'eventBusName':
                    $values[$arrayKey] = $value;

                    break;
                case 'events':
                    $values[$arrayKey] = $value ? $this->addValuesToCollectionModified($value, true, true) : $value;

                    break;
            }
        }

        return $values;
    }

    /**
     * @return array
     */
    public function modifiedToArrayRecursiveNotCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $this->transferMetadata[$property]['name_underscore'];

            if ($value instanceof AbstractTransfer) {
                $values[$arrayKey] = $value->modifiedToArray(true, false);

                continue;
            }
            switch ($property) {
                case 'eventBusName':
                    $values[$arrayKey] = $value;

                    break;
                case 'events':
                    $values[$arrayKey] = $value ? $this->addValuesToCollectionModified($value, true, false) : $value;

                    break;
            }
        }

        return $values;
    }

    /**
     * @return array
     */
    public function modifiedToArrayNotRecursiveNotCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $this->transferMetadata[$property]['name_underscore'];

            $values[$arrayKey] = $value;
        }

        return $values;
    }

    /**
     * @return array
     */
    public function modifiedToArrayNotRecursiveCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $property;

            $values[$arrayKey] = $value;
        }

        return $values;
    }

    /**
     * @return void
     */
    protected function initCollectionProperties()
    {
        $this->events = $this->events ?: new ArrayObject();
    }

    /**
     * @return array
     */
    public function toArrayNotRecursiveCamelCased()
    {
        return [
            'eventBusName' => $this->eventBusName,
            'events' => $this->events,
        ];
    }

    /**
     * @return array
     */
    public function toArrayNotRecursiveNotCamelCased()
    {
        return [
            'event_bus_name' => $this->eventBusName,
            'events' => $this->events,
        ];
    }

    /**
     * @return array
     */
    public function toArrayRecursiveNotCamelCased()
    {
        return [
            'event_bus_name' => $this->eventBusName instanceof AbstractTransfer ? $this->eventBusName->toArray(true, false) : $this->eventBusName,
            'events' => $this->events instanceof AbstractTransfer ? $this->events->toArray(true, false) : $this->addValuesToCollection($this->events, true, false),
        ];
    }

    /**
     * @return array
     */
    public function toArrayRecursiveCamelCased()
    {
        return [
            'eventBusName' => $this->eventBusName instanceof AbstractTransfer ? $this->eventBusName->toArray(true, true) : $this->eventBusName,
            'events' => $this->events instanceof AbstractTransfer ? $this->events->toArray(true, true) : $this->addValuesToCollection($this->events, true, true),
        ];
    }
}
