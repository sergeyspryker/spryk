<?php

/**
 * (c) Spryker Systems GmbH copyright protected
 */

namespace Generated\Shared\Transfer;

use Spryker\Shared\Kernel\Transfer\AbstractTransfer;

/**
 * !!! THIS FILE IS AUTO-GENERATED, EVERY CHANGE WILL BE LOST WITH THE NEXT RUN OF TRANSFER GENERATOR
 * !!! DO NOT CHANGE ANYTHING IN THIS FILE
 */
class FacetConfigTransfer extends AbstractTransfer
{
    /**
     * @var string
     */
    public const NAME = 'name';

    /**
     * @var string
     */
    public const PARAMETER_NAME = 'parameterName';

    /**
     * @var string
     */
    public const SHORT_PARAMETER_NAME = 'shortParameterName';

    /**
     * @var string
     */
    public const FIELD_NAME = 'fieldName';

    /**
     * @var string
     */
    public const TYPE = 'type';

    /**
     * @var string
     */
    public const IS_MULTI_VALUED = 'isMultiValued';

    /**
     * @deprecated Use aggregationParams instead
     */
    public const SIZE = 'size';

    /**
     * @var string
     */
    public const VALUE_TRANSFORMER = 'valueTransformer';

    /**
     * @var string
     */
    public const AGGREGATION_PARAMS = 'aggregationParams';

    /**
     * @var string|null
     */
    protected $name;

    /**
     * @var string|null
     */
    protected $parameterName;

    /**
     * @var string|null
     */
    protected $shortParameterName;

    /**
     * @var string|null
     */
    protected $fieldName;

    /**
     * @var string|null
     */
    protected $type;

    /**
     * @var bool|null
     */
    protected $isMultiValued;

    /**
     * @var int|null
     */
    protected $size;

    /**
     * @var string|null
     */
    protected $valueTransformer;

    /**
     * @var array
     */
    protected $aggregationParams = [];

    /**
     * @var array
     */
    protected $transferPropertyNameMap = [
        'name' => 'name',
        'Name' => 'name',
        'parameter_name' => 'parameterName',
        'parameterName' => 'parameterName',
        'ParameterName' => 'parameterName',
        'short_parameter_name' => 'shortParameterName',
        'shortParameterName' => 'shortParameterName',
        'ShortParameterName' => 'shortParameterName',
        'field_name' => 'fieldName',
        'fieldName' => 'fieldName',
        'FieldName' => 'fieldName',
        'type' => 'type',
        'Type' => 'type',
        'is_multi_valued' => 'isMultiValued',
        'isMultiValued' => 'isMultiValued',
        'IsMultiValued' => 'isMultiValued',
        'size' => 'size',
        'Size' => 'size',
        'value_transformer' => 'valueTransformer',
        'valueTransformer' => 'valueTransformer',
        'ValueTransformer' => 'valueTransformer',
        'aggregation_params' => 'aggregationParams',
        'aggregationParams' => 'aggregationParams',
        'AggregationParams' => 'aggregationParams',
    ];

    /**
     * @var array
     */
    protected $transferMetadata = [
        self::NAME => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'name',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::PARAMETER_NAME => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'parameter_name',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::SHORT_PARAMETER_NAME => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'short_parameter_name',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::FIELD_NAME => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'field_name',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::TYPE => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'type',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::IS_MULTI_VALUED => [
            'type' => 'bool',
            'type_shim' => null,
            'name_underscore' => 'is_multi_valued',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::SIZE => [
            'type' => 'int',
            'type_shim' => null,
            'name_underscore' => 'size',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::VALUE_TRANSFORMER => [
            'type' => 'string',
            'type_shim' => null,
            'name_underscore' => 'value_transformer',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
        self::AGGREGATION_PARAMS => [
            'type' => 'array',
            'type_shim' => null,
            'name_underscore' => 'aggregation_params',
            'is_collection' => false,
            'is_transfer' => false,
            'is_value_object' => false,
            'rest_request_parameter' => 'no',
            'is_associative' => false,
            'is_nullable' => false,
            'is_strict' => false,
        ],
    ];

    /**
     * @module Search
     *
     * @param string|null $name
     *
     * @return $this
     */
    public function setName($name)
    {
        $this->name = $name;
        $this->modifiedProperties[self::NAME] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return string|null
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getNameOrFail()
    {
        if ($this->name === null) {
            $this->throwNullValueException(static::NAME);
        }

        return $this->name;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireName()
    {
        $this->assertPropertyIsSet(self::NAME);

        return $this;
    }

    /**
     * @module Search
     *
     * @param string|null $parameterName
     *
     * @return $this
     */
    public function setParameterName($parameterName)
    {
        $this->parameterName = $parameterName;
        $this->modifiedProperties[self::PARAMETER_NAME] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return string|null
     */
    public function getParameterName()
    {
        return $this->parameterName;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getParameterNameOrFail()
    {
        if ($this->parameterName === null) {
            $this->throwNullValueException(static::PARAMETER_NAME);
        }

        return $this->parameterName;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireParameterName()
    {
        $this->assertPropertyIsSet(self::PARAMETER_NAME);

        return $this;
    }

    /**
     * @module Search
     *
     * @param string|null $shortParameterName
     *
     * @return $this
     */
    public function setShortParameterName($shortParameterName)
    {
        $this->shortParameterName = $shortParameterName;
        $this->modifiedProperties[self::SHORT_PARAMETER_NAME] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return string|null
     */
    public function getShortParameterName()
    {
        return $this->shortParameterName;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getShortParameterNameOrFail()
    {
        if ($this->shortParameterName === null) {
            $this->throwNullValueException(static::SHORT_PARAMETER_NAME);
        }

        return $this->shortParameterName;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireShortParameterName()
    {
        $this->assertPropertyIsSet(self::SHORT_PARAMETER_NAME);

        return $this;
    }

    /**
     * @module Search
     *
     * @param string|null $fieldName
     *
     * @return $this
     */
    public function setFieldName($fieldName)
    {
        $this->fieldName = $fieldName;
        $this->modifiedProperties[self::FIELD_NAME] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return string|null
     */
    public function getFieldName()
    {
        return $this->fieldName;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getFieldNameOrFail()
    {
        if ($this->fieldName === null) {
            $this->throwNullValueException(static::FIELD_NAME);
        }

        return $this->fieldName;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireFieldName()
    {
        $this->assertPropertyIsSet(self::FIELD_NAME);

        return $this;
    }

    /**
     * @module Search
     *
     * @param string|null $type
     *
     * @return $this
     */
    public function setType($type)
    {
        $this->type = $type;
        $this->modifiedProperties[self::TYPE] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return string|null
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getTypeOrFail()
    {
        if ($this->type === null) {
            $this->throwNullValueException(static::TYPE);
        }

        return $this->type;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireType()
    {
        $this->assertPropertyIsSet(self::TYPE);

        return $this;
    }

    /**
     * @module Search
     *
     * @param bool|null $isMultiValued
     *
     * @return $this
     */
    public function setIsMultiValued($isMultiValued)
    {
        $this->isMultiValued = $isMultiValued;
        $this->modifiedProperties[self::IS_MULTI_VALUED] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return bool|null
     */
    public function getIsMultiValued()
    {
        return $this->isMultiValued;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return bool
     */
    public function getIsMultiValuedOrFail()
    {
        if ($this->isMultiValued === null) {
            $this->throwNullValueException(static::IS_MULTI_VALUED);
        }

        return $this->isMultiValued;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireIsMultiValued()
    {
        $this->assertPropertyIsSet(self::IS_MULTI_VALUED);

        return $this;
    }

    /**
     * @module Search
     *
     * @deprecated Use aggregationParams instead
     *
     * @param int|null $size
     *
     * @return $this
     */
    public function setSize($size)
    {
        $this->size = $size;
        $this->modifiedProperties[self::SIZE] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @deprecated Use aggregationParams instead
     *
     * @return int|null
     */
    public function getSize()
    {
        return $this->size;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @deprecated Use aggregationParams instead
     *
     * @return int
     */
    public function getSizeOrFail()
    {
        if ($this->size === null) {
            $this->throwNullValueException(static::SIZE);
        }

        return $this->size;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @deprecated Use aggregationParams instead
     *
     * @return $this
     */
    public function requireSize()
    {
        $this->assertPropertyIsSet(self::SIZE);

        return $this;
    }

    /**
     * @module Search
     *
     * @param string|null $valueTransformer
     *
     * @return $this
     */
    public function setValueTransformer($valueTransformer)
    {
        $this->valueTransformer = $valueTransformer;
        $this->modifiedProperties[self::VALUE_TRANSFORMER] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return string|null
     */
    public function getValueTransformer()
    {
        return $this->valueTransformer;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\NullValueException
     *
     * @return string
     */
    public function getValueTransformerOrFail()
    {
        if ($this->valueTransformer === null) {
            $this->throwNullValueException(static::VALUE_TRANSFORMER);
        }

        return $this->valueTransformer;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireValueTransformer()
    {
        $this->assertPropertyIsSet(self::VALUE_TRANSFORMER);

        return $this;
    }

    /**
     * @module Search
     *
     * @param array|null $aggregationParams
     *
     * @return $this
     */
    public function setAggregationParams(array $aggregationParams = null)
    {
        if ($aggregationParams === null) {
            $aggregationParams = [];
        }

        $this->aggregationParams = $aggregationParams;
        $this->modifiedProperties[self::AGGREGATION_PARAMS] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @return array
     */
    public function getAggregationParams()
    {
        return $this->aggregationParams;
    }

    /**
     * @module Search
     *
     * @param mixed $aggregationParams
     *
     * @return $this
     */
    public function addAggregationParams($aggregationParams)
    {
        $this->aggregationParams[] = $aggregationParams;
        $this->modifiedProperties[self::AGGREGATION_PARAMS] = true;

        return $this;
    }

    /**
     * @module Search
     *
     * @throws \Spryker\Shared\Kernel\Transfer\Exception\RequiredTransferPropertyException
     *
     * @return $this
     */
    public function requireAggregationParams()
    {
        $this->assertPropertyIsSet(self::AGGREGATION_PARAMS);

        return $this;
    }

    /**
     * @param array $data
     * @param bool $ignoreMissingProperty
     *
     * @throws \InvalidArgumentException
     *
     * @return $this
     */
    public function fromArray(array $data, $ignoreMissingProperty = false)
    {
        foreach ($data as $property => $value) {
            $normalizedPropertyName = $this->transferPropertyNameMap[$property] ?? null;

            switch ($normalizedPropertyName) {
                case 'name':
                case 'parameterName':
                case 'shortParameterName':
                case 'fieldName':
                case 'type':
                case 'isMultiValued':
                case 'size':
                case 'valueTransformer':
                case 'aggregationParams':
                    $this->$normalizedPropertyName = $value;
                    $this->modifiedProperties[$normalizedPropertyName] = true;

                    break;
                default:
                    if (!$ignoreMissingProperty) {
                        throw new \InvalidArgumentException(sprintf('Missing property `%s` in `%s`', $property, static::class));
                    }
            }
        }

        return $this;
    }

    /**
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    public function modifiedToArray($isRecursive = true, $camelCasedKeys = false)
    {
        if ($isRecursive && !$camelCasedKeys) {
            return $this->modifiedToArrayRecursiveNotCamelCased();
        }
        if ($isRecursive && $camelCasedKeys) {
            return $this->modifiedToArrayRecursiveCamelCased();
        }
        if (!$isRecursive && $camelCasedKeys) {
            return $this->modifiedToArrayNotRecursiveCamelCased();
        }
        if (!$isRecursive && !$camelCasedKeys) {
            return $this->modifiedToArrayNotRecursiveNotCamelCased();
        }
    }

    /**
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    public function toArray($isRecursive = true, $camelCasedKeys = false)
    {
        if ($isRecursive && !$camelCasedKeys) {
            return $this->toArrayRecursiveNotCamelCased();
        }
        if ($isRecursive && $camelCasedKeys) {
            return $this->toArrayRecursiveCamelCased();
        }
        if (!$isRecursive && !$camelCasedKeys) {
            return $this->toArrayNotRecursiveNotCamelCased();
        }
        if (!$isRecursive && $camelCasedKeys) {
            return $this->toArrayNotRecursiveCamelCased();
        }
    }

    /**
     * @param mixed $value
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    protected function addValuesToCollectionModified($value, $isRecursive, $camelCasedKeys)
    {
        $result = [];
        foreach ($value as $elementKey => $arrayElement) {
            if ($arrayElement instanceof AbstractTransfer) {
                $result[$elementKey] = $arrayElement->modifiedToArray($isRecursive, $camelCasedKeys);

                continue;
            }
            $result[$elementKey] = $arrayElement;
        }

        return $result;
    }

    /**
     * @param mixed $value
     * @param bool $isRecursive
     * @param bool $camelCasedKeys
     *
     * @return array
     */
    protected function addValuesToCollection($value, $isRecursive, $camelCasedKeys)
    {
        $result = [];
        foreach ($value as $elementKey => $arrayElement) {
            if ($arrayElement instanceof AbstractTransfer) {
                $result[$elementKey] = $arrayElement->toArray($isRecursive, $camelCasedKeys);

                continue;
            }
            $result[$elementKey] = $arrayElement;
        }

        return $result;
    }

    /**
     * @return array
     */
    public function modifiedToArrayRecursiveCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $property;

            if ($value instanceof AbstractTransfer) {
                $values[$arrayKey] = $value->modifiedToArray(true, true);

                continue;
            }
            switch ($property) {
                case 'name':
                case 'parameterName':
                case 'shortParameterName':
                case 'fieldName':
                case 'type':
                case 'isMultiValued':
                case 'size':
                case 'valueTransformer':
                case 'aggregationParams':
                    $values[$arrayKey] = $value;

                    break;
            }
        }

        return $values;
    }

    /**
     * @return array
     */
    public function modifiedToArrayRecursiveNotCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $this->transferMetadata[$property]['name_underscore'];

            if ($value instanceof AbstractTransfer) {
                $values[$arrayKey] = $value->modifiedToArray(true, false);

                continue;
            }
            switch ($property) {
                case 'name':
                case 'parameterName':
                case 'shortParameterName':
                case 'fieldName':
                case 'type':
                case 'isMultiValued':
                case 'size':
                case 'valueTransformer':
                case 'aggregationParams':
                    $values[$arrayKey] = $value;

                    break;
            }
        }

        return $values;
    }

    /**
     * @return array
     */
    public function modifiedToArrayNotRecursiveNotCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $this->transferMetadata[$property]['name_underscore'];

            $values[$arrayKey] = $value;
        }

        return $values;
    }

    /**
     * @return array
     */
    public function modifiedToArrayNotRecursiveCamelCased()
    {
        $values = [];
        foreach ($this->modifiedProperties as $property => $_) {
            $value = $this->$property;

            $arrayKey = $property;

            $values[$arrayKey] = $value;
        }

        return $values;
    }

    /**
     * @return void
     */
    protected function initCollectionProperties()
    {
    }

    /**
     * @return array
     */
    public function toArrayNotRecursiveCamelCased()
    {
        return [
            'name' => $this->name,
            'parameterName' => $this->parameterName,
            'shortParameterName' => $this->shortParameterName,
            'fieldName' => $this->fieldName,
            'type' => $this->type,
            'isMultiValued' => $this->isMultiValued,
            'size' => $this->size,
            'valueTransformer' => $this->valueTransformer,
            'aggregationParams' => $this->aggregationParams,
        ];
    }

    /**
     * @return array
     */
    public function toArrayNotRecursiveNotCamelCased()
    {
        return [
            'name' => $this->name,
            'parameter_name' => $this->parameterName,
            'short_parameter_name' => $this->shortParameterName,
            'field_name' => $this->fieldName,
            'type' => $this->type,
            'is_multi_valued' => $this->isMultiValued,
            'size' => $this->size,
            'value_transformer' => $this->valueTransformer,
            'aggregation_params' => $this->aggregationParams,
        ];
    }

    /**
     * @return array
     */
    public function toArrayRecursiveNotCamelCased()
    {
        return [
            'name' => $this->name instanceof AbstractTransfer ? $this->name->toArray(true, false) : $this->name,
            'parameter_name' => $this->parameterName instanceof AbstractTransfer ? $this->parameterName->toArray(true, false) : $this->parameterName,
            'short_parameter_name' => $this->shortParameterName instanceof AbstractTransfer ? $this->shortParameterName->toArray(true, false) : $this->shortParameterName,
            'field_name' => $this->fieldName instanceof AbstractTransfer ? $this->fieldName->toArray(true, false) : $this->fieldName,
            'type' => $this->type instanceof AbstractTransfer ? $this->type->toArray(true, false) : $this->type,
            'is_multi_valued' => $this->isMultiValued instanceof AbstractTransfer ? $this->isMultiValued->toArray(true, false) : $this->isMultiValued,
            'size' => $this->size instanceof AbstractTransfer ? $this->size->toArray(true, false) : $this->size,
            'value_transformer' => $this->valueTransformer instanceof AbstractTransfer ? $this->valueTransformer->toArray(true, false) : $this->valueTransformer,
            'aggregation_params' => $this->aggregationParams instanceof AbstractTransfer ? $this->aggregationParams->toArray(true, false) : $this->aggregationParams,
        ];
    }

    /**
     * @return array
     */
    public function toArrayRecursiveCamelCased()
    {
        return [
            'name' => $this->name instanceof AbstractTransfer ? $this->name->toArray(true, true) : $this->name,
            'parameterName' => $this->parameterName instanceof AbstractTransfer ? $this->parameterName->toArray(true, true) : $this->parameterName,
            'shortParameterName' => $this->shortParameterName instanceof AbstractTransfer ? $this->shortParameterName->toArray(true, true) : $this->shortParameterName,
            'fieldName' => $this->fieldName instanceof AbstractTransfer ? $this->fieldName->toArray(true, true) : $this->fieldName,
            'type' => $this->type instanceof AbstractTransfer ? $this->type->toArray(true, true) : $this->type,
            'isMultiValued' => $this->isMultiValued instanceof AbstractTransfer ? $this->isMultiValued->toArray(true, true) : $this->isMultiValued,
            'size' => $this->size instanceof AbstractTransfer ? $this->size->toArray(true, true) : $this->size,
            'valueTransformer' => $this->valueTransformer instanceof AbstractTransfer ? $this->valueTransformer->toArray(true, true) : $this->valueTransformer,
            'aggregationParams' => $this->aggregationParams instanceof AbstractTransfer ? $this->aggregationParams->toArray(true, true) : $this->aggregationParams,
        ];
    }
}
