<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\Application;

use Spryker\Shared\Application\ApplicationConstants;
use Spryker\Zed\Application\ApplicationConfig as BaseApplicationConfig;

class ApplicationConfig extends BaseApplicationConfig
{
    /**
     * Specification:
     * - Returns base url of ZED.
     *
     * @api
     *
     * @return string
     */
    public function getApplicationBaseUrl(): string
    {
        return $this->getConfig()->get(ApplicationConstants::BASE_URL_ZED);
    }
}
