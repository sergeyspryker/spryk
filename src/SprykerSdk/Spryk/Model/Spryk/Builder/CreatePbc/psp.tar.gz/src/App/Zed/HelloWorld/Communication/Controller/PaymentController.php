<?php

/**
 * Copyright © 2016-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication\Controller;

use Spryker\Zed\Kernel\Communication\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @method \App\Zed\HelloWorld\Communication\HelloWorldCommunicationFactory getFactory()
 * @method \App\Zed\HelloWorld\Business\HelloWorldFacade getFacade()
 */
class PaymentController extends AbstractController
{
    /**
     * Payment Contoller
     * 
     * 
     * Must Accept a request object that should include the following structure:
     * @param \Symfony\Component\HttpFoundation\Request $request
     * Will validate the payment remotely in the PSP API, the process expects the answer to be included in the Response once the redirect is done
     * RedirectResponse Should be not expose any reference to paymentid nor notificationid as it is considered unsafe
     * Consider:
     * Reconnection Strategy
     * @param mixed $reconnectionStrategy can either be ReconnectOnce or ReconnectForever
     *
     * @version ${1:1.0.0
     * @return String
     * 
     * 
     * 
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function preAuthorizeAction(Request $request): RedirectResponse
    {
    }

    /**
     * Capture Payment
     * 
     * 
     * Once the authorisation of funds has been granted we can execute the captureAction, this action is not time constrained, 
     * therefore you should consider validating time restrictions and guaranteeing uniqueness of capture
     * @param \Symfony\Component\HttpFoundation\Request $request
     * Execute instantly the capture, validation should happen asyncronously
     * RedirectResponse Should be not expose any reference to paymentid nor notificationid as it is considered unsafe
     * Consider: - 

     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function captureAction(Request $request): RedirectResponse
    {
    }

    /**
    
     * Success Controller
     * 
     * 
     * After we have processed the notification of the capture process the frameword expects redirection to avalid sucess page, in this
     * controller you are expected to provide the payment information needed to render a complete thank you page. Also certain notifications weill be triggered
     * such as emails and sms that will need detailed payment confirmation
     * @param \Symfony\Component\HttpFoundation\Request $request
     * 
     * RedirectResponse Should be not expose any reference to paymentid nor notificationid as it is considered unsafe
     * Consider: Detail stored will consider also taxes and fees
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function successAction(Request $request): RedirectResponse
    {

    }

    /**
     * Cancel Controller
     * 
     * 
     * PSP requires a rollback mechanism to consider the possibility of canceled payment either by the merchant or by the payment provider.
     * Cancel Controller will be called externally and will need to process internally the order to the considered canceld state.
     * 
     * @param \Symfony\Component\HttpFoundation\Request $request
     * 
     * RedirectResponse Should be not expose any reference to paymentid nor notificationid as it is considered unsafe
     * Consider:  
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function cancelAction(Request $request): RedirectResponse
    {

    }
}
