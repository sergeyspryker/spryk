<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Business;

use Generated\Shared\Transfer\OrderPaymentEventTransfer;
use Generated\Shared\Transfer\PreAuthorizeRequestTransfer;
use Generated\Shared\Transfer\PreAuthorizeResponseTransfer;

interface HelloWorldFacadeInterface
{
    /**
     * Specification:
     * - Makes preauthorize call to Payment Gateway.
     * - Saves request and Payment Gateway response to DB.
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\PreAuthorizeRequestTransfer $preAuthorizeRequestTransfer
     *
     * @return \Generated\Shared\Transfer\PreAuthorizeResponseTransfer
     */
    public function preAuthorizePayment(PreAuthorizeRequestTransfer $preAuthorizeRequestTransfer): PreAuthorizeResponseTransfer;

    /**
     * Specification
     * - Makes capture call to Payment Gateway.
     * - Saves request and Payment Gateway response to DB.
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $orderPaymentEventTransfer
     *
     * @return void
     */
    public function capturePayment(OrderPaymentEventTransfer $orderPaymentEventTransfer): void;

    /**
     * Specification
     * - Makes refund call to Payment Gateway.
     * - Saves request and Payment Gateway response to DB.
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $orderPaymentEventTransfer
     *
     * @return void
     */
    public function refundPayment(OrderPaymentEventTransfer $orderPaymentEventTransfer): void;

    /**
     * Specification
     * - Makes cancel (void) call (capture with amount=0) to Payment Gateway.
     * - Saves request and Payment Gateway response to DB.
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $orderPaymentEventTransfer
     *
     * @return void
     */
    public function cancelReservationPayment(OrderPaymentEventTransfer $orderPaymentEventTransfer): void;
}
