<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication;

use Pyz\Zed\HelloWorld\Communication\Form\DataProvider\ConfigFormDataProvider;
use Pyz\Zed\HelloWorld\Communication\Tabs\ConfigFormTabs;
use Spryker\Zed\Gui\Communication\Tabs\TabsInterface;
use Spryker\Zed\Kernel\Communication\AbstractCommunicationFactory;
use Symfony\Component\Form\FormInterface;

/**
 * @method \App\Zed\HelloWorld\HelloWorldConfig getConfig()
 * @method \App\Zed\HelloWorld\Business\HelloWorldFacadeInterface getFacade()
 */
class HelloWorldCommunicationFactory extends AbstractCommunicationFactory
{
    /**
     * @return \Pyz\Zed\HelloWorld\Communication\Form\DataProvider\ConfigFormDataProvider
     */
    public function createConfigFormDataProvider(): ConfigFormDataProvider
    {
        return new ConfigFormDataProvider();
    }

    /**
     * @param mixed $data
     * @param array $options
     *
     * @return \Symfony\Component\Form\FormInterface
     */
    public function getConfigForm($data = null, array $options = []): FormInterface
    {
        return $this->getFormFactory()->create(PaymentConfigForm::class, $data, $options);
    }

    /**
     * @return \Spryker\Zed\Gui\Communication\Tabs\TabsInterface
     */
    public function createConfigFormTabs(): TabsInterface
    {
        return new ConfigFormTabs();
    }
}
