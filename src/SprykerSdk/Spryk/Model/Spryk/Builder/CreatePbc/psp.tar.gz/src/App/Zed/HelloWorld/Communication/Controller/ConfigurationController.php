<?php

/**
 * Copyright © 2016-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication\Controller;

use Spryker\Zed\Kernel\Communication\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;

class ConfigurationController extends AbstractController
{
    /**
     * Configuration Controller
     *   
     * Some specific PBCs will have Configuration requirements in order to execute correctly ej multistore parameters, Credentials for external services etc
     * Consider presenting the business user the fields needed to persist in this step that will happen just after activation of the PBC
     *
     * @param \Symfony\Component\HttpFoundation\Request $request - Controller will be called when the user chooses to configure PBC after installation
     * @version ${1:1.0.0
     * 
     * 
     * 
     *
     * @return array<string, mixed>
     */
    public function indexAction(Request $request): array
    {
        $form = $this->getFactory()
            ->getConfigForm()
            ->handleRequest($request);

        return $this->viewResponse([
            'configForm' => $form->createView(),
            'configFormTabs' => $this->getFactory()->createConfigFormTabs()->createView(),
        ]);
    }
}
