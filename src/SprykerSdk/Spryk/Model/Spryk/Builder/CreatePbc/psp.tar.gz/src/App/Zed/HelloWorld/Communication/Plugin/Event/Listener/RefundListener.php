<?php

/**
 * Copyright © 2016-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication\Plugin\Event\Listener;

use Spryker\Shared\Kernel\Transfer\TransferInterface;
use Spryker\Zed\Event\Dependency\Plugin\EventHandlerInterface;
use Spryker\Zed\Kernel\Communication\AbstractPlugin;

/**
 * @method \App\Zed\HelloWorld\Communication\HelloWorldCommunicationFactory getFactory()
 * @method \App\Zed\HelloWorld\Business\HelloWorldFacade getFacade()
 */
class RefundListener extends AbstractPlugin implements EventHandlerInterface
{
    /**
     * 
     * Must Accept a transfer object that contains these specific params:
     * 
     * 
     * Will be handling the event based on the transfer object configuration and make the refundPayment accordingly
     * 
     * Reconnection Strategy
     * @param mixed $reconnectionStrategy can either be ReconnectOnce or ReconnectForever.
     * ConfigurationProvider
     * @param mixed $configProvider Name of the configuration to use to execute this component..
     * @version ${1:1.0.0
     * @return String
     * 
     * 
     *
     * 
     * Configuration

     *
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $transfer
     * @param string $eventName
     *
     * @return void
     */
    public function handle(TransferInterface $transfer, $eventName)
    {
        $this->getFacade()->refundPayment($transfer);
    }
}
