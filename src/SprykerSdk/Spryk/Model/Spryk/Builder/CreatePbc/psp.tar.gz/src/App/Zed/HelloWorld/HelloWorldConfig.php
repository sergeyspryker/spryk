<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld;

use Spryker\Zed\Kernel\AbstractBundleConfig;

class HelloWorldConfig extends AbstractBundleConfig
{
    public const EVENT_LISTENED_ORDER_PAYMENT_REFUND_REQUESTED = 'order_payment_refund_requested';

    public const EVENT_LISTENED_ORDER_PAYMENT_CONFIRMATION_REQUESTED = 'order_payment_confirmation_requested';

    public const EVENT_LISTENED_ORDER_PAYMENT_CANCEL_RESERVATION_REQUESTED = 'payment_cancel_reservation_requested';
}
