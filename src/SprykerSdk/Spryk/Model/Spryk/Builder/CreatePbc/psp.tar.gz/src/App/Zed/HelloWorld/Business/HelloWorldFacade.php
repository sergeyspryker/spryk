<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Business;

use Generated\Shared\Transfer\OrderPaymentEventTransfer;
use Generated\Shared\Transfer\PreAuthorizeRequestTransfer;
use Generated\Shared\Transfer\PreAuthorizeResponseTransfer;
use Spryker\Zed\Kernel\Business\AbstractFacade;

/**
 * @method \App\Zed\HelloWorld\Business\HelloWorldBusinessFactory getFactory()
 */
class HelloWorldFacade extends AbstractFacade implements HelloWorldFacadeInterface
{
    /**
     * {@inheritdoc}
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\PreAuthorizeRequestTransfer $preAuthorizeRequestTransfer
     *
     * @return \Generated\Shared\Transfer\PreAuthorizeResponseTransfer
     */
    public function preAuthorizePayment(PreAuthorizeRequestTransfer $preAuthorizeRequestTransfer): PreAuthorizeResponseTransfer
    {
        // TODO: Implement preAuthorizePayment() method.
    }

    /**
     * {@inheritdoc}
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $orderPaymentEventTransfer
     *
     * @return void
     */
    public function capturePayment(OrderPaymentEventTransfer $orderPaymentEventTransfer): void
    {
        // TODO: Implement capturePayment() method.
    }

    /**
     * {@inheritdoc}
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $orderPaymentEventTransfer
     *
     * @return void
     */
    public function refundPayment(OrderPaymentEventTransfer $orderPaymentEventTransfer): void
    {
        // TODO: Implement refundPayment() method.
    }

    /**
     * {@inheritdoc}
     *
     * @api
     *
     * @param \Generated\Shared\Transfer\OrderPaymentEventTransfer $orderPaymentEventTransfer
     *
     * @return void
     */
    public function cancelReservationPayment(OrderPaymentEventTransfer $orderPaymentEventTransfer): void
    {
        // TODO: Implement cancelReservationPayment() method.
    }
}
