<?php

/**
 * Copyright © 2016-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication\Plugin\Event\Subscriber;

use App\Zed\HelloWorld\Communication\Plugin\Event\Listener\CancelReservationListener;
use App\Zed\HelloWorld\Communication\Plugin\Event\Listener\CaptureListener;
use App\Zed\HelloWorld\Communication\Plugin\Event\Listener\RefundListener;
use App\Zed\HelloWorld\HelloWorldConfig;
use Spryker\Zed\Event\Dependency\EventCollectionInterface;
use Spryker\Zed\Event\Dependency\Plugin\EventSubscriberInterface;
use Spryker\Zed\Kernel\Communication\AbstractPlugin;

class HelloWorldPaymentEventSubscriber extends AbstractPlugin implements EventSubscriberInterface
{
    /**
     * @api
     *
     * @param \Spryker\Zed\Event\Dependency\EventCollectionInterface $eventCollection
     *
     * @return \Spryker\Zed\Event\Dependency\EventCollectionInterface
     */
    public function getSubscribedEvents(EventCollectionInterface $eventCollection)
    {
        $this->addRefundActionListener($eventCollection);
        $this->addConfirmActionListener($eventCollection);
        $this->addCancelReservationActionListener($eventCollection);

        return $eventCollection;
    }

    /**
     * @param \Spryker\Zed\Event\Dependency\EventCollectionInterface $eventCollection
     *
     * @return void
     */
    protected function addRefundActionListener(EventCollectionInterface $eventCollection): void
    {
        $eventCollection->addListener(HelloWorldConfig::EVENT_LISTENED_ORDER_PAYMENT_REFUND_REQUESTED, new RefundListener());
    }

    /**
     * @param \Spryker\Zed\Event\Dependency\EventCollectionInterface $eventCollection
     *
     * @return void
     */
    protected function addConfirmActionListener(EventCollectionInterface $eventCollection): void
    {
        $eventCollection->addListener(HelloWorldConfig::EVENT_LISTENED_ORDER_PAYMENT_CONFIRMATION_REQUESTED, new CaptureListener());
    }

    /**
     * @param \Spryker\Zed\Event\Dependency\EventCollectionInterface $eventCollection
     *
     * @return void
     */
    protected function addCancelReservationActionListener(EventCollectionInterface $eventCollection): void
    {
        $eventCollection->addListener(HelloWorldConfig::EVENT_LISTENED_ORDER_PAYMENT_CANCEL_RESERVATION_REQUESTED, new CancelReservationListener());
    }
}
