<?php

/**
 * Copyright © 2016-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\HelloWorld\Communication\Controller;

use Spryker\Zed\Kernel\Communication\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;

class ConfigurationController extends AbstractController
{
    /**
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array<string, mixed>
     */
    public function indexAction(Request $request): array
    {
        $form = $this->getFactory()
            ->getConfigForm()
            ->handleRequest($request);

        return $this->viewResponse([
            'configForm' => $form->createView(),
            'configFormTabs' => $this->getFactory()->createConfigFormTabs()->createView(),
        ]);
    }
}
