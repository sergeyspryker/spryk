<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\Application\Communication\Console;

use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Spryker\Zed\Kernel\Communication\Console\Console;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\HttpFoundation\Response;

/**
 * @method \Spryker\Zed\Application\Communication\ApplicationCommunicationFactory getFactory()
 */
class PbcRegistrationConsole extends Console
{
    public const COMMAND_NAME = 'pbc:app:registration';

    /**
     * @return void
     */
    protected function configure(): void
    {
        $this->setName(static::COMMAND_NAME)
            ->setDescription('Does request to the pbc-registry in order to be added to the catalog list.');
    }

    /**
     * @param \Symfony\Component\Console\Input\InputInterface $input
     * @param \Symfony\Component\Console\Output\OutputInterface $output
     *
     * @return int
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $baseUrl = $this->getFactory()->getConfig()->getApplicationBaseUrl();

        $manifest = file_get_contents(APPLICATION_ROOT_DIR . '/config/pbc/manifest.json');
        $manifest = str_replace('$URL$', $baseUrl, $manifest);

        $request = new Request(
            'POST',
            'http://registry.pbc.spryker.local/pbc/register',
            [
                'Content-Type' => 'application/json',
            ],
            $manifest
        );
        $response = (new Client())->sendRequest($request);

        if ($response->getStatusCode() !== Response::HTTP_NO_CONTENT) {
            return static::CODE_ERROR;
        }

        return static::CODE_SUCCESS;
    }
}
