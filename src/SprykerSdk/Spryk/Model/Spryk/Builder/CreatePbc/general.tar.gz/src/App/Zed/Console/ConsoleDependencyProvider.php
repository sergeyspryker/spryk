<?php

/**
 * Copyright © 2021-present Spryker Systems GmbH. All rights reserved.
 * Use of this software requires acceptance of the Evaluation License Agreement. See LICENSE file.
 */

namespace App\Zed\Console;

use Spryker\Zed\Cache\Communication\Console\EmptyAllCachesConsole;
use Spryker\Zed\Console\ConsoleDependencyProvider as SprykerConsoleDependencyProvider;
use Spryker\Zed\Development\Communication\Console\CodePhpstanConsole;
use Spryker\Zed\Development\Communication\Console\CodeStyleSnifferConsole;
use Spryker\Zed\Development\Communication\Console\GenerateIdeAutoCompletionConsole;
use Spryker\Zed\Development\Communication\Console\GenerateZedIdeAutoCompletionConsole;
use Spryker\Zed\EventAwsSnsBroker\Communication\Console\EventAwsSnsBrokerCreateSubscribersConsole;
use Spryker\Zed\EventAwsSnsBroker\Communication\Console\EventAwsSnsBrokerCreateTopicsConsole;
use Spryker\Zed\Installer\Communication\Console\InitializeDatabaseConsole;
use Spryker\Zed\Kernel\Communication\Console\Console;
use Spryker\Zed\Kernel\Container;
use Spryker\Zed\Router\Communication\Plugin\Console\RouterCacheWarmUpConsole;
use Spryker\Zed\Router\Communication\Plugin\Console\RouterDebugZedConsole;
use Spryker\Zed\Scheduler\Communication\Console\SchedulerCleanConsole;
use Spryker\Zed\Scheduler\Communication\Console\SchedulerResumeConsole;
use Spryker\Zed\Scheduler\Communication\Console\SchedulerSetupConsole;
use Spryker\Zed\Scheduler\Communication\Console\SchedulerSuspendConsole;
use Spryker\Zed\Transfer\Communication\Console\DataBuilderGeneratorConsole;
use Spryker\Zed\Transfer\Communication\Console\RemoveTransferConsole;
use Spryker\Zed\Transfer\Communication\Console\TransferGeneratorConsole;
use Spryker\Zed\Translator\Communication\Console\GenerateTranslationCacheConsole;
use Spryker\Zed\Twig\Communication\Console\CacheWarmerConsole;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ConsoleDependencyProvider extends SprykerConsoleDependencyProvider
{
    protected const COMMAND_SEPARATOR = ':';

    /**
     * @param \Spryker\Zed\Kernel\Container $container
     *
     * @return \Symfony\Component\Console\Command\Command[]
     */
    protected function getConsoleCommands(Container $container): array
    {
        return [
            new DataBuilderGeneratorConsole(),
            new EmptyAllCachesConsole(),
            new EventAwsSnsBrokerCreateTopicsConsole(),
            new EventAwsSnsBrokerCreateSubscribersConsole(),
            new RemoveTransferConsole(),
            new RouterCacheWarmUpConsole(),
            new RouterDebugZedConsole(),
            new TransferGeneratorConsole(),
            new GenerateTranslationCacheConsole(),

            new SchedulerSetupConsole(),
            new SchedulerCleanConsole(),
            new SchedulerSuspendConsole(),
            new SchedulerResumeConsole(),

            // Next definitions of consoles are kinda stubs for commands that are called during the installation process for each store and region (pbc payment is the DEFAULT store and has own region).
            // This commands is registered in suite-nonsplit/config/install/docker.yml in the 'init-storages-per-store' and 'init-storages-per-region' sections.
            new class extends Console {
                /**
                 * @return void
                 */
                protected function configure()
                {
                    $this->setName('queue:setup');

                    parent::configure();
                }

                /**
                 * @param \Symfony\Component\Console\Input\InputInterface $input
                 * @param \Symfony\Component\Console\Output\OutputInterface $output
                 *
                 * @return int
                 */
                protected function execute(InputInterface $input, OutputInterface $output): int
                {
                    $output->writeln('Blocked ' . $this->getName());

                    return static::CODE_SUCCESS;
                }
            },
            new class extends Console {
                /**
                 * @return void
                 */
                protected function configure()
                {
                    $this->setName('search:setup:sources');
                    $this->setAliases([
                        'propel:model:build',
                        'propel:database:create',
                        'propel:tables:drop',
                        'propel:migration:delete',
                        'propel:diff',
                        'transfer:entity:generate',
                        'setup:init-db',
                        'propel:migrate',
                        'propel:pg-sql-compat',
                        'propel:install',
                        'propel:schema:copy',
                    ]);

                    parent::configure();
                }

                /**
                 * @param \Symfony\Component\Console\Input\InputInterface $input
                 * @param \Symfony\Component\Console\Output\OutputInterface $output
                 *
                 * @return int
                 */
                protected function execute(InputInterface $input, OutputInterface $output): int
                {
                    $output->writeln('Blocked ' . $this->getName());

                    return static::CODE_SUCCESS;
                }
            },
            new class extends Console {
                /**
                 * @return void
                 */
                protected function configure()
                {
                    $this->setName('data:import');
                    $this->addOption('config', 'c', InputOption::VALUE_REQUIRED);

                    parent::configure();
                }

                /**
                 * @param \Symfony\Component\Console\Input\InputInterface $input
                 * @param \Symfony\Component\Console\Output\OutputInterface $output
                 *
                 * @return int
                 */
                protected function execute(InputInterface $input, OutputInterface $output): int
                {
                    $output->writeln('Blocked ' . $this->getName());

                    return static::CODE_SUCCESS;
                }
            },
            new class extends Console {
                /**
                 * @return void
                 */
                protected function configure()
                {
                    $this->setName('product-label:relations:update');

                    parent::configure();
                }

                /**
                 * @param \Symfony\Component\Console\Input\InputInterface $input
                 * @param \Symfony\Component\Console\Output\OutputInterface $output
                 *
                 * @return int
                 */
                protected function execute(InputInterface $input, OutputInterface $output): int
                {
                    $output->writeln('Blocked ' . $this->getName());

                    return static::CODE_SUCCESS;
                }
            },
        ];
    }
}
